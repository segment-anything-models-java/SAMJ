# Copyright (c) Meta Platforms, Inc. and affiliates.
# All rights reserved.

# This source code is licensed under the license found in the
# LICENSE file in the root directory of this source tree.

from hydra import initialize_config_module
from hydra.core.global_hydra import GlobalHydra
    
from importlib.metadata import version, PackageNotFoundError

if not GlobalHydra.instance().is_initialized():
    initialize_config_module("sam2", version_base="1.2")

try:
    __version__ = version("SAM-2")
except PackageNotFoundError:
    __version__ = "unknown"

